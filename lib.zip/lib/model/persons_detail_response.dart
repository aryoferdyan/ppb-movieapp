// import 'persons_detail.dart';

// class PersonsDetailResponse {
//   final PersonDetail personDetail;
//   final String error;

//   PersonsDetailResponse(this.personDetail, this.error);

//   PersonsDetailResponse.fromJson(Map<String, dynamic> json)
//       : personDetail = PersonDetail.fromJson(json),
//         error = "";

//   PersonsDetailResponse.withError(String errorValue)
//       : personDetail = PersonDetail(null, null, null, null, "", null),
//         error = errorValue;
// }
